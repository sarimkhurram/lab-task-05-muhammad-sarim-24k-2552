#include <stdio.h>

int main()
{
    int age;
    printf("Enter your age : ");
    scanf("%d", &age);

    if (age > 0 && age <= 18)
    {
        if (age >= 13 && age <= 18)
        {
            printf("You are a teenager\n");
        }

        else
        {
            printf("You are a child\n");
        }
    }

    else
    {
        if (age >= 50)
        {
            printf("You are a Senior\n");
        }
        else
        {
            printf("You are an adult\n");
        }
    }
    return 0;
}