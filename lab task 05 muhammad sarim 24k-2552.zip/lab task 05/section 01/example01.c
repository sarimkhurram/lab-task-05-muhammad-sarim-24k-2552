#include <stdio.h>

int main(){
    int score ;
    printf("Enter score : ") ;
    scanf("%d",&score) ;

    if (score >= 90) {
        if (score >= 95) {

            printf("Grade: A+\n");
        } 
        else {
            printf("Grade: A\n");
        }
    }

    else if(score>=80){
        if (score>=85)
            printf("grade: B+\n") ;
        else
            printf("Grade : B\n") ;
    }

    else
        printf("grade c or lower\n") ;
   
    return 0 ;

}
