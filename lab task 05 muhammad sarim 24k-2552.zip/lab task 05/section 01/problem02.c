#include <stdio.h>

int main(){

    int num ;
    printf("Enter a Number : ") ;
    scanf("%d",&num) ;

    if(num>0){
        if(num%2==0)
            printf("It's is an even number\n") ;
        else    
            printf("It's an odd number") ;
    }
    else if (num<0){
        printf("It is negative number\n") ;
    }
    else
        printf("It's Zero\n") ;

    return 0 ;
}