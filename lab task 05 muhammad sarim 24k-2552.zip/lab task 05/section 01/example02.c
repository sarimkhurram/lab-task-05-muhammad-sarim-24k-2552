#include <stdio.h>

int main(){
    int temp ;
    printf("enter the temperature in celsius: "); 
    scanf("%d", &temp);

    if(temp>=30){
        if(temp>=40){
            printf("it is very hot outside!\n");
        }

        else{
            printf("it is hot outside\n") ;
        }  
    }

    else if(temp>=20){
        printf("it is warm outside\n") ;
    }

    else if(temp>=10){
        printf("it is cool outside\n") ;
    }

    else{
        printf("it is cold outside\n") ;
    }

    return 0 ;
}