#include <stdio.h>

int main(){
    int age,income,credit_score ;

    printf("Enter age,income and creditcore(out of 100) : ") ;
    scanf("%d%d%d",&age,&income,&credit_score) ;

    if(age>=18 && credit_score>70 && income>=100000){
        printf("You are eligible for loan\n") ;
    }
    else
        printf("you are not eligible for loan\n") ;

    return 0 ;
}