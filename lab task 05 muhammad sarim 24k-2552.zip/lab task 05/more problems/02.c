#include <stdio.h>

int main(){

    int attendance,assigment,exam ;
    char grade ;

    printf("enter attendate perentage : ") ;
    scanf("%d",&attendance) ;

    printf("enter assignment perentage : ") ;
    scanf("%d",&assigment) ;

    printf("enter exam perentage : ") ;
    scanf("%d",&exam) ;

    float wieghtage = (exam * 0.7) + (attendance * 0.2) + (assigment * 0.1) ;
    printf("Your final score is %.2f\n",wieghtage) ;

    if(attendance>80)
    {
        if (wieghtage>=80)
        {
            printf("A") ;
        }
        else
        {
            if (wieghtage>=70)
                printf("B") ;
            else{
                if (wieghtage>=60)
                {
                    printf("C") ;
                }
                else{
                    if (wieghtage>=50)
                    {
                        printf("D") ;
                    }
                    else
                        printf("F") ;
                    
                }
                
            }
        }
        
    }

    else{
        printf("F") ;
    }

    


    return 0 ;
}