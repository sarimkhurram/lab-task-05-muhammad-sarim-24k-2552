#include <stdio.h>

int main(){

    int num1,num2,num3,greatest ;
    printf("enter 3 numbers to find greatest of them : ") ;
    scanf("%d%d%d",&num1,&num2,&num3) ;

    if(num1>=num2){
        if (num1>=num3)
        {
            printf("num1 is the greatest\n") ;
        }
        else
        {
            printf("num3 is the greatest\n") ;
        }
        
    }

    else
    {
        if(num2>=num3)
        {
            printf("num2 is the greatest\n") ;
        }
        else
        {
            printf("num3 is the greatest\n") ;
        }
    }


    return 0 ;
}