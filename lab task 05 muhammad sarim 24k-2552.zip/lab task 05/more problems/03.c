#include <stdio.h>

int main(){

    char character ;
    char key;
    char encrypted ;

    printf("Enter a character for encryption and decryption : ") ;
    scanf(" %c",&character) ;

    printf("Enter a key for encryption and decryption : ") ;
    scanf(" %c",&key) ;

    encrypted = character ^ key ;
    char decrypted = encrypted ^ key ;

    printf("Encrypted  : %c",encrypted) ;
    printf("Decrypted  : %c",decrypted) ;







    return 0 ;
}