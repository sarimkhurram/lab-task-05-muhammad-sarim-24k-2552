#include <stdio.h>

int main(){

    int num;
    printf("enter a number: ");
    scanf("%d", &num);
    (num % 2 == 0) ? printf("it is even \n") : printf("it is odd \n") ;
    return 0 ;
}