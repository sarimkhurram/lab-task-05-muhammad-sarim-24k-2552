#include <stdio.h>

int main(){
    int num ;
    printf("Enter a number: ") ;
    scanf("%d",&num) ;

    num == 0 ? printf("number is zero\n") : num > 0 ? printf("number is positive\n") : printf("number is negative\n") ;

    return 0 ;
}