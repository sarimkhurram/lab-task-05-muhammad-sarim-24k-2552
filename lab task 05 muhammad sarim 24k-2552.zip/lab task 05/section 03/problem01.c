#include <stdio.h>

int main(){
    int num1,num2 ;
    printf("enter numbers to check which one is maximum : ") ;
    scanf("%d%d",&num1,&num2) ;

    num1>num2 ? printf("number 1 is greater\n") : printf("number 2 is greater\n") ;


    return 0 ;
}