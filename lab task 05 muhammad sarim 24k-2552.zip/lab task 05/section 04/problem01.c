#include <stdio.h>

int main(){
                                                // 4 / 0100
                                                // 5 / 0101
    int num1,num2 ;                             //     0001 
    printf("enter two numbers to swap: ");
    scanf("%d%d",&num1,&num2) ;

    num1 = num1 ^ num2 ;
    num2 = num1 ^ num2 ;
    num1 = num1 ^ num2 ;

    printf("swaped number is %d %d",num1,num2) ;


    return 0 ;
}
