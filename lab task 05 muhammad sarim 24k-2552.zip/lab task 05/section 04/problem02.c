#include <stdio.h>

int main(){
    int count=0 ;
    int num ;
    printf("Enter number to count 1s in it : ") ;
    scanf("%d",&num) ;
    
    while (num) {
        num = num & (num - 1); 
        count++;
    }

    printf("number of 1s are : %d",count) ;


    return 0 ;
}