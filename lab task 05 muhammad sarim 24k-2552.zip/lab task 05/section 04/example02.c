#include <stdio.h>

int main(){

    int a = 5; 
    int result = a << 1; 
    printf("result after left shift: %d\n", result); 


    return 0 ;
}