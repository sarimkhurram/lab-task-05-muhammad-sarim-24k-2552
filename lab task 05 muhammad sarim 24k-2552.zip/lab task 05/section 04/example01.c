#include <stdio.h>

int main(){

    int a = 5; 
    int b = 9; 
    printf("a AND b = %d\n", a & b); 
    printf("a OR b = %d\n", a | b); 

    printf("a XOR b = %d\n", a ^ b); 
    printf("a NOT = %d\n", ~a);

    return 0 ;
}