#include <stdio.h>

int main(){

    int age;
    char character ;
    printf("Enter your age : ");
    scanf("%d", &age);

    printf("Enter citizenship status using first letter of country in small char : ") ;
    scanf(" %c",&character) ;

    if(age >=18 && character=='p'){
        printf("you are eligible to vote\n") ;
    }

    else
        printf("you are not eligible to vote \n") ;



    return 0 ;
}