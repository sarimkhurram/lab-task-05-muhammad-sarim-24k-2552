#include <stdio.h>

int main(){
    int num ;
    printf("Enter a number to check if it;s divisible by both 3 and 5 : ") ;
    scanf("%d",&num) ;

    if(num%5==0 && num%3== 0){
        printf("It is divisible by both 3 and 5\n");
    }
    else
        printf("It is not divisible by both 3 and 5\n");   
    return 0 ;
}