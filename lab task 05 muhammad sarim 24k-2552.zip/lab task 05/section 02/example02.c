#include <stdio.h>

int main(){
    int score1,score2,score3 ;
    printf("Enter 3 test scores : ") ;
    scanf("%d%d%d",&score1,&score2,&score3) ;

    if (score1 > 50 && score2 > 50 && score3 > 50) 
        printf("you passed all the tests\n");
    else 
        printf("you didn't pass all the tests\n");
    return 0;
}