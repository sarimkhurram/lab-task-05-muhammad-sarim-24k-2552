#include <stdio.h>

int main(){

    int age = 20;
    int licence_available = 1;
    if (age >= 18 && licence_available) {
        printf("you are eligible to drive\n");
    } 
    else {
        printf("you are not eligible to drive\n");
    }


    return 0 ;
}